package com.edu.vehicle.controller;

import java.util.List;


//import org.slf4j.Logger;

//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.vehicle.controller.VehicleController;
import com.edu.vehicle.entity.Customer;
import com.edu.vehicle.entity.Vehicle;
import com.edu.vehicle.error.GlobalExceptionHandling;
import com.edu.vehicle.service.VehicleService;


@RestController 
public class VehicleController {
	
	//Inject an object of VehicleService
	@Autowired
	private VehicleService vehicleService;
	
	//save the record
	                              //post
	  //http://localhost:portno/vehicles
	
	@PostMapping("/vehicle")
	public ResponseEntity<Vehicle> saveVehicle(@RequestBody Vehicle vehicle) {
		Vehicle savedVehicle = vehicleService.saveVehicle(vehicle);
		return new ResponseEntity<Vehicle>(savedVehicle, HttpStatus.CREATED);
	}
	
	//get  records by id
		@GetMapping("/vehicles/{insuranceId}") //http://localhost:8889/vehicles/1
		public ResponseEntity<List<Vehicle>> getVehicleById(@PathVariable("insuranceId") Long insuranceId) throws GlobalExceptionHandling {			
			List<Vehicle> vcl = vehicleService.getVehicleById(insuranceId);
			return new ResponseEntity<List<Vehicle>>(vcl, HttpStatus.OK);
		}
		
		//delete
		@DeleteMapping("/vehiclesdelete/{insuranceId}")
		public ResponseEntity<List<Vehicle>> vehicleDeleteById(@PathVariable("insuranceId") Long insuranceId) throws GlobalExceptionHandling {
			List<Vehicle> vcl = vehicleService.vehicleDeleteById(insuranceId);
			return new ResponseEntity<List<Vehicle>>(vcl,HttpStatus.ACCEPTED);
		}
				
		//update 
		@PutMapping("/vehicles/{insuranceId}")
		public ResponseEntity<Vehicle> vehicleUpdateById(@PathVariable("insuranceId") Long insuranceId,@RequestBody Vehicle vehicle) throws GlobalExceptionHandling {			
			Vehicle vehicleUpdated = vehicleService.vehicleUpdateById(insuranceId,vehicle);
			return new ResponseEntity<Vehicle>(vehicleUpdated, HttpStatus.CREATED);
		}
		
		//get all vehicles
		@GetMapping("/getAllVehicles")
		public ResponseEntity<List<Vehicle>> getAllVehicles(){
			List<Vehicle> vehicles = vehicleService.getAllVehicles();
			return new ResponseEntity<List<Vehicle>>(vehicles, HttpStatus.OK);
		}
		
//		get by name
		@GetMapping("/vehicles/{vehicleName}")
		public List<Vehicle> findByVehicleName(@PathVariable("vehicleName") String vehicleName){
			return vehicleService.findByVehicleName(vehicleName);
		}
}
	
	
