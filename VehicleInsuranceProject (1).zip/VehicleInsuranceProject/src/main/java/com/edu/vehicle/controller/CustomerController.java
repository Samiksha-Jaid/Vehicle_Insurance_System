package com.edu.vehicle.controller;

import java.util.List;


import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.vehicle.entity.Customer;
import com.edu.vehicle.entity.Vehicle;
import com.edu.vehicle.error.GlobalExceptionHandling;
import com.edu.vehicle.repository.CustomerRepository;
import com.edu.vehicle.repository.VehicleRepository;
import com.edu.vehicle.service.CustomerService;
import com.edu.vehicle.service.VehicleService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {
	
	@Autowired
	private  CustomerService  customerService;

	@Autowired
	private VehicleService vehicleService;

	@Autowired
	private VehicleRepository vehicleRepository;
	
	@Autowired
	private CustomerRepository customerRepository;

//	Insert Record
	@PostMapping("/customer")
	public ResponseEntity<Customer> addCustomer(@Valid @RequestBody Customer customer) {
		Customer customerSaved = customerService.addCustomer(customer);
		return new ResponseEntity<Customer>(customerSaved, HttpStatus.CREATED);
	}

//	getCustomerById
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<List<Customer>> getCustomerById(@PathVariable("customerId") Long customerId) throws GlobalExceptionHandling {
		List<Customer> customerRetrieved = customerService.getCustomerById(customerId);
		return new ResponseEntity<List<Customer>>(customerRetrieved, HttpStatus.OK);
	}

//	update
	@PutMapping("/update/{customerId}")
	public ResponseEntity<Customer> updateCustomerById(@Valid @PathVariable("customerId") Long customerId,@RequestBody Customer customer) throws GlobalExceptionHandling {	
		Customer customerUpdated = customerService.updateCustomerById(customerId,customer);
		return new ResponseEntity<Customer>(customerUpdated, HttpStatus.CREATED);	
	}

//	delete 
	@DeleteMapping("/delete/{customerId}")
	public ResponseEntity<List<Customer>> deleteCustomerById(@PathVariable("customerId") Long customerId) throws GlobalExceptionHandling {
		List<Customer> cust = customerService.deleteCustomerById(customerId);
		return new ResponseEntity<List<Customer>>(cust,HttpStatus.ACCEPTED);
	}

//	findAllCustomers
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> findAllCustomer(){
		List<Customer> customers = customerService.findAllCustomer();
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}

//		get by name
		@GetMapping("/customers/{customerName}")
		public List<Customer> findByCustomerName(@PathVariable("customerName") String customerName){
			return customerService.findByCustomerName(customerName);
		}
	
//	assign customer to vehicle
	@ResponseBody
	@PutMapping("/customerAssignVehicle/{customerId}/vehicle/{insuranceId}")
	public ResponseEntity<Customer> customerAssignVehicle(@PathVariable Long customerId, @PathVariable Long insuranceId) throws GlobalExceptionHandling {
		Customer updated =  customerService.customerAssignVehicle(customerId,insuranceId);
		return new ResponseEntity<Customer>(updated, HttpStatus.CREATED);
	}
}

