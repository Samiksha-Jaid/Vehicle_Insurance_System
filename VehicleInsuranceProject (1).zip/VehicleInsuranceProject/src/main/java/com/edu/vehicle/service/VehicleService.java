package com.edu.vehicle.service;

import java.util.List;

import com.edu.vehicle.entity.Vehicle;
import com.edu.vehicle.error.GlobalExceptionHandling;

public interface VehicleService {

	public Vehicle saveVehicle(Vehicle vehicle);

	public List<Vehicle> getVehicleById(Long insuranceId) throws GlobalExceptionHandling;

	public List<Vehicle> vehicleDeleteById(Long insuranceId) throws GlobalExceptionHandling;

	public Vehicle vehicleUpdateById(Long insuranceId, Vehicle vehicle) throws GlobalExceptionHandling;

	public List<Vehicle> getAllVehicles();

	public List<Vehicle> findByVehicleName(String vehicleName);

}