package com.edu.vehicle.error;

public class GlobalExceptionHandling extends Exception
{
        public GlobalExceptionHandling(String s) {
        	
        	super(s);
        	
        }
        
	
}
