import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from 'src/app/component/customer/customer.component';
import { Vehicle } from 'src/app/component/vehicleInsurance/vehicle-insurance.component';

@Injectable({
  providedIn: 'root'
})
export class InsuranceDataService {

  constructor(private httpClient:HttpClient ) { }

  // vehicle
  retrieveAllInsurance(){
    return this.httpClient.get<Vehicle[]>(`http://localhost:8889/getAllVehicles`);
  }

  deleteInsurance(insuranceId:number){
    return this.httpClient.delete(`http://localhost:8889/vehiclesdelete/${insuranceId}`);
  }

//   findInsuranceById
  retriveInsurance(insuranceId:number){ //call this from addVehicle.ts

    return this.httpClient.get<Vehicle>(`http://localhost:8889/getvehicle/${insuranceId}`);

  }

  //updateRecord

  updateInsurance(insuranceId: number, addVehicle: Vehicle) {
    return this.httpClient.put<Vehicle>(`http://localhost:8889/updatevehicle/${insuranceId}`,addVehicle);
                                
}

addInsurance(addVehicle: Vehicle){
  return this.httpClient.post<Vehicle>(`http://localhost:8889/vehicle`,addVehicle);       
}


// customer
retrieveAllCustomer(){
  return this.httpClient.get<Customer[]>(`http://localhost:8889/customers`);
}

deleteCustomer(customerId:number){
  return this.httpClient.delete(`http://localhost:8889/delete/${customerId}`);
}

//   findInsuranceById
retriveCustomer(customerId:number){ //call this from addCustomer.ts

  return this.httpClient.get<Customer>(`http://localhost:8889/customer/${customerId}`);

}

//updateRecord

updateCustomer(customerId: number, addCustomer: Customer) {
  return this.httpClient.put<Customer>(`http://localhost:8889/update/${customerId}`,addCustomer);
                              
}

addCustomer(addCustomer: Customer){
return this.httpClient.post<Customer>(`http://localhost:8889/customer`,addCustomer);       
}

}
