import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InsuranceDataService } from 'src/app/service/data/insurance-data.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit{
  //to connect backend
  customers: Customer[] = []; // array of object

  //Inject object of TOdoService
constructor(private insuranceService:InsuranceDataService,private router:Router) {}

  ngOnInit(): void {
    this.refreshCustomer();
  }

  refreshCustomer(){
    this.insuranceService.retrieveAllCustomer().subscribe(
      response=>{
        console.log(response);
        this.customers=response;
      }
    )
  }

  //Delete
  deleteCustomer(customerId:number){
    console.log(`deleteCustomer  id=${customerId}`)
    //call deleteCustomer from service
    this.insuranceService.deleteCustomer(customerId).subscribe(
     response=>{
       this.refreshCustomer();
     }
    )
}

updateCustomer(customerId:number){
  console.log(`update record id=${customerId}`);

  this.router.navigate(['addCustomer',customerId]);
 }

 addCustomer(){
    console.log("add Customer")
    this.router.navigate(['addCustomer',-1]); //navigate with -1 to add
    }


}

export class Customer{  //user defined typescript class
 
  constructor(public customerId:number,
    public customerName:string,
    public customerAdharno:number,
    public customerPanno:string,
    public customerPhone:number,
    public customerDrivinglisenceno:string,
    public insuranceId:number
      ) {}
}
